---
id: changelog-latest
title: Changelog (v1)
---

1.0.7
-----

- QurasDBとの連動の下にTransactionの送受信機能を追加した。

1.0.2
-----

- QurasDB APIサーバ通信モジュールを追加した。

1.0.1 
-----

- QURASブロックチェーンのAPIを利用するための基本ライブラリが開発された。

  0. Wallet関連キーの生成、変換部分が追加された。
  1. QURASノードとのRPC通信モジュールの機能が完成された。